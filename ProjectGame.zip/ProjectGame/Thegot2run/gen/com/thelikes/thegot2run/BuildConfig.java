/** Automatically generated file. DO NOT MODIFY */
package com.thelikes.thegot2run;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}