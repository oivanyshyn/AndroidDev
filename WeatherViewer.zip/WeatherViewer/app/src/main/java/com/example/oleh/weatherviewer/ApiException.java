package com.example.oleh.weatherviewer;

public class ApiException extends Exception
{
    public ApiException(String message, Exception e)
    {
        super(message, e);
    }
}
