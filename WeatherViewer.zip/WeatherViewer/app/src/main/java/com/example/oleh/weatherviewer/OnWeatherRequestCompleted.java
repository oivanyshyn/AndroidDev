package com.example.oleh.weatherviewer;

public interface OnWeatherRequestCompleted {

    void onTaskCompleted(WeatherData data);
    void onTaskFailed(Exception e);
}
